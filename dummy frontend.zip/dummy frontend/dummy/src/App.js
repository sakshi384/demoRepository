import logo from './logo.svg';
import './App.css';
import Demotable from './Components/Dummytable';

function App() {
  return (
    <div className="App">
      
      <Demotable></Demotable>
    </div>
  );
}

export default App;
